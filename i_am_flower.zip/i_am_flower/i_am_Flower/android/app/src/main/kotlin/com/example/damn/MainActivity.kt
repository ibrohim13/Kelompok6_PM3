package com.example.damn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
